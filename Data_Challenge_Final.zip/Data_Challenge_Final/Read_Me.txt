Application built using R Shiny

libraries used:
	ggplot2
	shiny
	dplyr

Application Files:
ui.R
server.R

Application specific folders:
rsconnect: to deploy shiny app in shiny.io


Guides:
Business Insights.pdf: Business Insights and the approach taken.
